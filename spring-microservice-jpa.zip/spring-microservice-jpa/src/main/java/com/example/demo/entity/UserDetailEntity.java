package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

@Entity
@Table
@Getter
@NoArgsConstructor
public class UserDetailEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String city;

    public UserDetailEntity(String city, UserEntity user) {
        this.city = city;
        this.user = user;
    }

    @OneToOne
    @JoinColumn(name = "s_id", referencedColumnName = "id")
    private UserEntity user;
}
