curl -X POST -H "Content-type: application/json" http://localhost:8090/users -d'{
    "name":"Aurica",
    "city":"Costestii din vale"
}' -v

curl -X GET http://localhost:8090/users -v
