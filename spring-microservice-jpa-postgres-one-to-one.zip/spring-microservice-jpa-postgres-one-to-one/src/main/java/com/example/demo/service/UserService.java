package com.example.demo.service;

import com.example.demo.dto.User;
import com.example.demo.entity.UserDetailEntity;
import com.example.demo.entity.UserEntity;
import com.example.demo.repository.UserDetailRepository;
import com.example.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final UserDetailRepository userDetailRepository;

    @Transactional
    public void saveUser(User user) {
        UserEntity userEntity = new UserEntity(user.getName());

        UserDetailEntity userDetail = new UserDetailEntity(user.getCity(), userEntity);

        userRepository.save(userEntity);
        userDetailRepository.save(userDetail);
    }

    @Transactional
    public List<User> listUsers() {
        return userRepository.listWithDetails()
                .stream().map(u -> new User(u.getName(), u.getUserDetail().getCity()))
                .toList();
    }
}
